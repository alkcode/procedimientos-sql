echo "INICIA PROCESO "

date

echo "31/10/2022	QUINCENA 20 DEL 2022"
dbaccess m4prod eagg_go.sql;

date

echo "FIN PROCESO"